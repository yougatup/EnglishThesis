Here is the input format of our project

10 24 200

In the first line, input the number of cars, the number of intervals, and maximum capacity of intervals.

Next,

3 63

It means that car 1 have to be charged about 3 units, each unit it consumes 63 capacity.

Like this, input all of the information for the number of cars

After that, input the cost of each interval like

0.008

then, the input is over.

